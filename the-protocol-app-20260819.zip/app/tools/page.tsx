import { ToolsIndex } from "@/components/ToolExperience";
export default function Page(){return <ToolsIndex/>}
