CREATE TABLE `mood_entries` (
	`id` integer PRIMARY KEY AUTOINCREMENT NOT NULL,
	`user_id` text NOT NULL,
	`date` text NOT NULL,
	`mood_value` integer NOT NULL,
	`mood_label` text NOT NULL,
	`energy` integer NOT NULL,
	`stress` integer NOT NULL,
	`gratitude` integer NOT NULL,
	`note` text DEFAULT '' NOT NULL,
	`created_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL,
	`updated_at` text DEFAULT CURRENT_TIMESTAMP NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `mood_entries_user_date_unique` ON `mood_entries` (`user_id`,`date`);--> statement-breakpoint
CREATE INDEX `mood_entries_user_date_idx` ON `mood_entries` (`user_id`,`date`);